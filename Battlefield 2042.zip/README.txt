amd gpu users may need to remove 
-worldrender.lighttilecspathenable 0

if not using 1920x1080 users may need to change values for
-perfoverlay.fpsdisplayoffsetx
-perfoverlay.fpsdisplayoffsety

anti aliasing can be disabled with a small frame loss
https://github.com/fr33thytweaks/Disable-Anti-Aliasing

to fix texture quality not rendering in native resolution
-set "GstRender.LightingQuality 1" in config
-or "Lighting Quality" in game to medium

test range
-ABJZ66